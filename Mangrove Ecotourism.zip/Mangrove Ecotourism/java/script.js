document.querySelector(".search-button").addEventListener("click", function (e) {
    e.preventDefault();
    const searchInput = document.querySelector(".search-input");
    if (searchInput.style.display === "none" || searchInput.style.display === "") {
        searchInput.style.display = "block";
        searchInput.focus();
    } else {
        searchInput.style.display = "none";
    }
});
